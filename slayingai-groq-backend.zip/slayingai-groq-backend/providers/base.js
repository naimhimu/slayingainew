export class ChatProvider {
  // Should return an async generator of string chunks
  stream(_messages) { throw new Error("not implemented"); }
}
